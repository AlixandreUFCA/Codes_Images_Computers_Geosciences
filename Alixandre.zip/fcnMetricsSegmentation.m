% image toolbox
% MATLAB file
% 
% fcnMetricsSegmentation.m
% Computa o erro entre as imagens
%
% function [ERRO_DIF] = fcnMetricsSegmentation(ImagemReal, ImagemSegmentada)
%
% input:  ImagemReal:  Imagem original sem ruido
%         ImagemSegmentada: Imagem segmentada por algum m�todo
% output: ERRO_DIF: Diferen�a entre pixels        
% example: [ERRO_DIF] = fcnMetricsSegmentation(ImagemR, ImagemS);
%
function [ERRO_DIF]  = fcnMetricsSegmentation(ImagemReal, ImagemSegmentada)

% ImagemR = double(ImagemReal/max(ImagemReal(:)));
[x,y] = size(ImagemReal);
ImagemReal = double(ImagemReal);
ImagemSegmentada = double(ImagemSegmentada);
ImagemDif = abs(ImagemReal-ImagemSegmentada) > 0 ;
ImagemDif = double(ImagemDif);

ERRO_DIF = sum(sum(abs(ImagemDif)))/(x*y);

return