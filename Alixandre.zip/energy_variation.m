function [f,df] = energy_variation(z,Gb,a,g,n)
%Fun�ao que calcula a varia��o total do mapa de energia f = -\sum(|\nabla E|) e
%sua derivada df em um ponto z, para o gradiente e as mapas de par�metros dados
%
%Sintax: [f,df] = energy_variation(z,Gb,a,g,n)
%
%z = ponto inicial 
%Gb = gradiente da imagem
%a = mapa dos valores de alfa estimados
%g = mapa dos valores de gama estimados
%n = n�mero de looks
%
%OBS: Gb, a, g - devem estar vetorizados.
%

f = sum(-((z.^(2.*n-1)).*((g+n.*z.^2).^(a-n))).*((2*n^n).*gamma(n-a)./((g.^a).*gamma(-a).*gamma(n))).*Gb);
df = sum(-Gb .*(( 2*(n^n).*gamma(n-a)./((g.^a).*gamma(-a).*gamma(n))) .* (((g + n*z^2).^(a-n)) .* (z.^(2*n-2)).*(2*n-1) + ((a-n)*2*n*z^(2*n)).*(g + n*(z^2)).^(a-n-1))));