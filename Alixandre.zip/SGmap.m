function [E,alfa,gama] = SGmap(img,N)
% Fun��o para mapeamento de imagens SAR por meio dos par�metros da
% distribui��o G-Amplitude Zero
%
%Sintax: SGmap(img,N)
%
%img: imagem SAR
%N: N�mero de looks
%
%A fun��o cria 3 arquivos de sa�da.
%Arquivo 1: Mapa de par�metros alfa, gama e J(informa��o de janelamento)
%Arquivo 2: Armazena o resultado da etapa de maximiza��o das varia��es de
%energia
%Arquivo 3: Armazena o mapa de energia
%
%O algoritmo � dividido em duas etapas 
%
%1a Etapa: S�o estimados os par�metros alfa e gama para cada ponto da
%imagem, utilizando estimativa por momentos ou MaxVer
%
%2a Etapa: �  estiamdo o valor de z que maximiza as varia��es de energia.
%Utiliza-se m�todos num�ricos para maximiza��o da fun��o de energia: 
%varia��es do m�todo de Newton.
%
%

clc
fprintf('Fun��o para mapeamento de imagens SAR por meio dos par�metros da distribui��o G-Amplitude Zero\n\n');
%name = input('Nome do teste:');
name='teste';

clc
fprintf('\n\n-------------------------- CONFIGURA��O-------------------------------\n\n')

fprintf('************Estimativa dos mapas de par�metros de rugossidade e intensidade***********\n');
fprintf('M�todos:\n 0. Carregar Arquivo\n 1. M�todo dos Momentos\n 2. M�todos dos momentos com janelamento adaptativo\n 3. ML\n 4. ML Otimizado\n');
%op1 = input('Op��o:');
op1=1;
filename=-1;
op11=-1;
if (op1==0 || op11==0)
    filename = input('Arquivo:');
elseif (op1==3 || op1==4)
    fprintf('Inicializa��o do m�todo de ML.\n')
    fprintf('M�todos:\n 0. Carregar Arquivo\n 1. M�todo dos Momentos\n 2. M�todos dos momentos com janelamento adaptativo\n 3. Par�metros constantes\n');
    op11= input('Op��o:');
end

fprintf('\n\n************Estimativa de z para maximiza��o das varia��es de energia************\n');
fprintf('M�todos:\n 1. Newton-Raphson\n 2. quasi-Newton (BFSG)\n 3. Trust-Region Newton\n');
%op2 = input('Op��o:');
op2=2;

fprintf('\n\n --------------------------PROCESSANDO--------------------------\n\n');
%% 1a Etapa: Estiamtiva de Par�metros

J = 3;
if op1==0 || op11==0
    load(filename)
    fprintf('\n\nArquivo de par�metros carregado.');
elseif op1==1 || op11==1
%     J = input('\n\nTamanho da janela de estimativa para o m�todo dos momentos:');
    [alfa,gama,alfa_true] = estimativa_MO(img,N,J);
    save(strcat(name,'_1.mat'),'alfa','gama','J','op1');
elseif op1==2 || op11==02
    J = input('\n\nTamanho m�ximo da janela de estimativa para o m�todo dos momentos:');
    [alfa,gama] = estimativa_MO(img,N,J);
    save(strcat(name,'_1.mat'),'alfa','gama','J','op1');
elseif op1==3
    save(strcat(name,'_1.mat'),'alfa','gama','op1');
elseif op1==4
    save(stracat(name,'_1.mat'),'alfa','gama','op1');
end

%% 2a etapa: maximiza��o das varia��es de energia
tic
[h,hx] = hist(double(img(:)),256);
zo = hx(h==max(h))   %Start point utilizado: moda do histograma dos dados
%zo=1.6500e+004;
% if op2==5
%     op2 = input('M�todo Utilizado:');
%     filename = strcat(name,'2.mat');
%     load(filename)
%     fprintf(fid,strcat('Arquivo de maximiza��o carregado: %s',filename,'\n'));
%     fprintf(fid,'M�todo utilizado: %d\n',op2);
% end

if op2==1 
    [zmax,grad] = energy_max(zo,img,alfa,gama,alfa_true,N,op2);
    save(strcat(name,'_2.mat'),'zmax','grad','zo');
elseif op2==2 
    [zmax,grad] = energy_max(zo,img,alfa,gama,alfa_true,N,op2);
    save(strcat(name,'_2.mat'),'zmax','grad','zo');

elseif op2==3 
    [zmax,grad] = energy_max(zo,img,alfa,gama,N,op2);
    save(strcat(name,'_2.mat'),'zmax','grad','zo');
end
toc
fprintf('\n\n --------------------------RESULTADOS--------------------------');
%% Calculo do mapa de energia
fprintf('\nStart Point (zo): %.4f',zo);
fprintf('\nz estimado: %.4f\n',zmax);
fprintf('Gradiente alcan�ado: %0.4f\n',grad);
E = gA0_acumulada(zmax,alfa,gama,N);
save(strcat(name,'_3.mat'),'E','zmax');
escrevelogfile(name,filename,op1,op11,op2,J,zo,zmax,grad);
fprintf('Mapa de energia salvo.\nArquivos salvos no diret�rio atual.\n\n\n\n');