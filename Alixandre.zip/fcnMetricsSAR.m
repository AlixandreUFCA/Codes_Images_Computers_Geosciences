% image toolbox
% MATLAB file
% 
% fcnMetricsSAR.m
% Computa o SSI: Speckle Suppression Index, o ENL: Equivalent Number of 
% Looks, o  STM: Standard Deviation to Mean Ratio e o SMPI: Speckle
% Suppression and Mean Preservation Index 
%
% function [SSI ENL STM SMPI CC ESIh ESIv] = fcnMetricsSAR(ImagemRuidosa, ImagemFiltrada)
%
% input:  ImagemRuidosa:  Imagem com ru�do
%         ImagemFiltrada: Imagem ap�s aplica��o do filtro
% output: SSI: Speckle Suppression Index (Coeficiente de Varian�a)        
%         ENL: Equivalent Number of Looks
%         STM: Standard Deviation to Mean Ratio 
%         SMPI: Speckle Suppression and Mean Preservation Index  
%         CC: Correlation Coeficient
%         ESIh: Edge Save Index (horizontal)
%         ESIv: Edge Save Index (vertical)
% example: [SSI] = snr(f, eu);
%
function [SSI ENL STM SMPI CC ESIh ESIv]  = fcnMetricsSAR(ImagemRuidosa, ImagemFiltrada)

ImagemRuidosa  = double(ImagemRuidosa);
ImagemFiltrada = double(ImagemFiltrada);

mean_ImagemRuidosa = mean(ImagemRuidosa(:));
mean_ImagemFiltrada = mean(ImagemFiltrada(:));

tmp        = ImagemRuidosa - mean_ImagemRuidosa;
var_ImagemRuidosa  = sum(tmp(:).^2);

tmp        = ImagemFiltrada - mean_ImagemFiltrada;
var_ImagemFiltrada  = sum(tmp(:).^2);

SSI = (sqrt(var_ImagemFiltrada) * mean_ImagemRuidosa)/(mean_ImagemFiltrada * sqrt(var_ImagemRuidosa));

if var_ImagemFiltrada == 0
    ENL = 999.99;
    STM = 999.99;
    SMPI = 999.99;
else
    ENL = (mean_ImagemFiltrada*mean_ImagemFiltrada)/var_ImagemFiltrada;
    STM = sqrt(var_ImagemFiltrada)/mean_ImagemFiltrada;
    SMPI= (sqrt(var_ImagemFiltrada)/sqrt(var_ImagemRuidosa))*(1+abs(mean_ImagemRuidosa - mean_ImagemFiltrada));
end


CC = corrcoef(ImagemRuidosa,ImagemFiltrada);
%CC = (mean((ImagemRuidosa - mean_ImagemRuidosa).*(ImagemFiltrada - mean_ImagemFiltrada))/(sqrt(var_ImagemFiltrada)*sqrt(var_ImagemRuidosa));


% calcula o ESI
[m n] = size(ImagemRuidosa);
NumESI = 0;
DenESI = 0;
for i=1:m
    for j=1:(n-1)        
        NumESI = NumESI + abs(ImagemFiltrada(i,j+1) - ImagemFiltrada(i,j));
        DenESI = DenESI + abs(ImagemRuidosa(i,j+1) - ImagemRuidosa(i,j));
    end
end

if DenESI == 0
   ESIh = 999.99;
else
   ESIh = NumESI/DenESI;
end   

NumESI = 0;
DenESI = 0;
for j=1:n
    for i=1:(m-1)        
        NumESI = NumESI + abs(ImagemFiltrada(i+1,j) - ImagemFiltrada(i,j));
        DenESI = DenESI + abs(ImagemRuidosa(i+1,j) - ImagemRuidosa(i,j));
    end
end

if DenESI == 0
   ESIv = 999.99;
else
   ESIv = NumESI/DenESI;
end      
   
   
return