function phi = RegisPAMIGa0_Original(Img,F,sigma_phi,N)
%
%General algorithm for fast level set evolution, based in the one
%provided by Kaihua Zhang, Huihui Song and Lei Zhang
%
%Img: gray level image, for view only.
%
%N: number of iteractions.
%
%Fo: static propagation velocity matrix or an aditional parameter for
%dinamic model, see the code block in line 38.
%
%sigma_phi: level set parameters, see
%
%    "Active contours driven by local image fitting energy" 
%    Pattern Recognition, 2010
%    Kaihua Zhang, Huihui Song and Lei Zhang
%
%Suggest:
% sigma_phi = 0.5;
%
%K = fspecial('gaussian',2*round(2*sigma)+1,sigma);
%F = F-((max(F(:))-min(F(:)))/10);
%F = F.*(F>0)/max(F(:)) + F.*(F<0)/-min(F(:));
%[nrow,ncol] = size(Img);
%phi = ones(nrow,ncol);
%phi(15:nrow-15,15:ncol-15) = -1;
%

phi =imread('level_zero.bmp');
[X,Y] = size(Img);
phi = -(2*phi(1:X,1:Y)-1);

F=bordas2d(F,2,'mirror');
Img=bordas2d(Img,2,'mirror');
phi=bordas2d(phi,2,'mirror');

% figure;  imagesc(Img,[0 255]);colormap(gray);hold on;
K_phi = fspecial('gaussian',5,sigma_phi);
% contour(phi,[0 0],'b');
timestep = 0.5;
epsilon = 0.95;
Fo=F;
% S=zeros(1,N+15);
p=1;
% for n = 1:N
n=1;
m1 = mean(Fo(phi>0));
m2 = mean(Fo(phi<0));
%X = (-1+((m1>=m2)*2));
while(((p(end))>1e-7)||(n<150))&&((n<N))
      %%%%%%%%%%%%%Velocity model%%%%%%%%%%%
      %Insert here your dinamic level set model
      %If velocity model is static, you should comment this block and F=Fo
                    A1 = sum(phi(phi>0));
                    A2 = -sum(phi(phi<0));
                    m1 = mean(Fo(phi>0));
                    m2 = mean(Fo(phi<0));
                    Df(n) = abs(m1-m2);
                    if n>50
                        S(n-49)=mean(Df(n-50:n));
                        p=diff(S);
                    end
                    F = -(Fo*(1/A1 + 1/A2) - m1/A1 - m2/A2);
                    F = F.*(F>0)/max(F(:)) + F.*(F<0)/-min(F(:));
        %             
      %%%%%%%%%%%%%%%end block%%%%%%%%%%%%%%%%%
      n=n+1;
      phi = LIF(phi,timestep,epsilon,F);
      phi = conv2(phi,K_phi,'same');
      if mod(n,5)==0
        pause(0.0001);
        imagesc(Img,[0 255]);colormap(gray)
        hold on;contour(phi,[0 0],'y','LineWidth',0.5);
        iterNum=[num2str(n), ' iterations'];        
        title(iterNum);        
        hold off;
        p(end);
      end
      
end

% figure;
% mesh(phi);
% figure;
% imagesc(Img,[0 255]);colormap(gray)
% hold on;
% contour(phi,[0 0],'y','LineWidth',0.5);
% figure,
% edg = final_level_set(phi);
% % imagesc(Img,[0 255]);colormap(gray)
% % hold on;contour(phi,[0 0],'y','LineWidth',1.5);
% % figure,plot(S),grid on
% % figure,plot(diff(S)),grid on

%edg = edg(3:end-2,3:end-2);

phi = phi(3:X+2,3:Y+2);

function edg = final_level_set(D)

[A,B] = size(D);
edg = zeros(A,B);
Dm = min(D(:));
D(:,1:2)=Dm;D(:,end-1:end)=Dm;D(1:2,:)=Dm;D(end-1:end,:)=Dm;
c = round(contour(D,[0 0]));

for i = 1:length(c)
    if (c(1,i)~=0 && c(2,i)~=0)
        edg(c(2,i),c(1,i)) = 255;      
    end
end