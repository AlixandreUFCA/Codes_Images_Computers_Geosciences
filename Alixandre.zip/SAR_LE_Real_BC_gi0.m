%  --- INICIALIZA O PROGRAMA LIMPANDO VARIAVEIS ---
clc;
close all;
clear all;
warning('off');

tCalculosIni = tic;
% -------------------------------------------

% -- PARAMETROS DE GERA��O DA IMAGEM CONTAMINADA --

%zonas extremamente heterogeneas:  ]-3 0[
%zonas heterogeneas             :  ]-6 -3]
%zonas homogeneas               :  ]-inf -6]

% imagem = load('ALOS_BC_hh_amp.mat', 'Recorte13');
% imagem_ga0 = double(imagem.Recorte13);
% imagem_ga0 = imagem_ga0.^2;
% imagem_gi0 = imagem_ga0.^2;

imagem_gi0 = textread('10.txt');
imagem_ga0 = sqrt(imagem_gi0);

colorseg = [1 0];
nclasses = 2;

Nlooks = 1; % N�mero de Visadas (Looks) [1 2 3 4 5 6 7 8]
MGo = 1;    % M�dia da Distribui��o Go;

L = Nlooks; % N�mero de Visadas (Looks) 
mi = MGo;   % M�dia da Distribui��o Go;

% ----- PARAMETROS PARA M�TODO DE MONTE CARLO -----
maxInt=1;
% -------------------------------------------------

% -------- PARAMETROS PARA M�TODO DO HUANG --------
Sigma = 0.5;
e = 1; 
dt=0.5;
N=100;
Lo = double(createLevelSetInitial(size(imagem_gi0)));
% -------------------------------------------------

% ---  PARAMETROS PARA ESTIMA��O E SEGMENTA�AO  ---
windowSize = 5;
TJanela3 = [3 3]; TJanela5 = [5 5]; TJanela7 = [7 7];
% -------------------------------------------------

tipo_teste = 4;  % 1- dado original    (SAR Data)
                 % 2- m�todo alixandre (M_alfa)
                 % 3- m�todo MoRE
                 % 4- m�todo proposto

disp 'Estimando par�metros ' ;
if tipo_teste == 1
    % para imagem original
    LE = imagem_gi0;     
end
if tipo_teste == 2
    % para metodologia do Alixandre
    
    % usando solver
    [A G] = estima_gi0_logcum_otim(imagem_gi0, L, 5);    
    
    % usando m�todo fast
    % [A G] = estima_gi0_logcum_fast(imagem_gi0, 1, 5); %<- tem alguma coisa errada. s� funciona se utilizar o fast.
    
    
    LE = A;       
end
if tipo_teste == 3
    % para o m�todo MoRE
     
     %usando solver
     %[As Gs] = estima_ga0_momentos_opt_par(imagem_ga0, windowSize, L); %
     
     %usando interpola��o
     [As Gs] = estima_ga0_momentos(imagem_gi0, windowSize, L);
         
     disp 'Calculando entropia' ;
     [renyi]= entropia_renyi_ga0(As, Gs, 4, windowSize, L);          
     LE = renyi;
end    
if tipo_teste == 4
    % para o m�todo proposto
     
     %usando interpola��o
     [As Gs] = estima_gi0_momentos(imagem_gi0, windowSize, L);
             
      disp 'Calculando Logarithmic expectation - LE' ;
     [LE]= LogExpectetion(As, Gs, L);
     LE_ori = LE;
     LE = fcnFilterMedian(LE_ori, getnhood(strel('rectangle',TJanela3)));   
end    


disp 'Calculando as dist�ncias estoc�sticas' ;
% Calculando Dist�ncias Estocasticas da imagem real

% melhor resultado huang-modificado

Z_fr = imagem_gi0(87:146, 43: 97);
Z_br = imagem_gi0(82:135, 331: 377);

m_fr = mean(Z_fr(:));
m_br = mean(Z_br(:));
limiar = (m_fr+m_br)/2; % limiar para o m�todo original do Huang

SD_r = Gi0_arith_distance(Z_fr(:),Z_br(:),L, L); 
DoS = 1/SD_r;

tCalculosFim = toc (tCalculosIni);

tOtsuIni = tic;

disp 'Segmentando imagem' ;


% SEGMENTA��O POR THRESHOLD - 
thresh = multithresh(LE,1); 
seg_THR = imquantize(LE,thresh,colorseg);
RGB_THR = label2rgb(seg_THR);
imagemSegmentada_THR = double(seg_THR);

tOtsuFim = toc (tOtsuIni);

tKmeanIni = tic;

% SEGMENTA��O POR KMEANS
imageKmeans  = imgKmeans(LE, 2);
seg_KMS = labelgray(imageKmeans, colorseg);
imagemSegmentada_KMS = double(seg_KMS);    

tKmeanFim = toc (tKmeanIni);


tHuangIni = tic;

% SEGMENTA��O POR HUANG -
if tipo_teste == 1
   N=230;
  [LevelSetHuang imagemHuang] = level_set_huang_modified(Lo, dt, e, imagem_gi0, 1, -0.1, N, LE, nclasses-1, limiar);
else
  [LevelSetHuang imagemHuang] = level_set_huang_modified(Lo, dt, e, imagem_gi0, 1, -0.5, N, LE, nclasses-1);
end
  
Seg_Huang = imagemHuang > 0;
imagemSegmentada_Huang = double (Seg_Huang);

tHuangFim = toc (tHuangIni);

% SEGMENTA��O POR ZHANG -
% [LevelSetZhang imagemZhang] = level_set_demo(LE, L, 1, 0.5, dt, N*10);
% SegZhang = imagemZhang > 0;
% imagemSegmentada_Zhang = double (SegZhang);


tRegisIni = tic;

% SEGMENTA��O POR REGIS -
if tipo_teste == 1
   E = SGmap(imagem_ga0, L);
   phi = RegisPAMIGa0_Original(E,E,0.05,100)
   imagemSegmentada_Regis = double (phi > 0);    
%    phi = level_set_pami(E,0.5,0.25,200)
%    imagemSegmentada_Regis = double (phi > 0);
end
if tipo_teste == 2
   phi = RegisPAMIGi0_Original(LE,LE,0.35,370);
   imagemSegmentada_Regis = double (phi > 0);  
end
if tipo_teste == 3
   phi = RegisPAMIGi0_Original(LE,LE,0.10,100);
   imagemSegmentada_Regis = double (phi > 0);  
end
if tipo_teste == 4
   phi = RegisPAMIGi0_Original(LE,LE,0.35,370);
   imagemSegmentada_Regis = double (phi > 0);  
end

tRegisFim = toc (tRegisIni);


tAlanIni = tic;
option = 'median_leveset'; % median_leveset, GFLS
% SEGMENTA��O POR ALAN -
if tipo_teste == 1
    % SEGMENTA��O POR ALAN -
    L = 1;
    N = 1000;
    R = 6;
    w = 30;
    Th = 1e-2;
    Nb = 8;

    [phi, psi] = mlsh3(imagem_gi0,L,N,R,w,Th,Nb,option);
    imagemSegmentada = double (psi > 0);
    imagemSegmentada_Alan = imagemSegmentada(:,:,1);
end
if tipo_teste == 2
    % SEGMENTA��O POR ALAN - Modificado
    L = 1;
    N = 100;
    R = 6;
    w = 70;
    Th = 1e-2;
    Nb = 8;

    %%
    [phi, psi] = mlsh3_Ric(LE,L,N,R,w,Th,Nb,option);
    imagemSegmentada = double (psi > 0);
    imagemSegmentada_Alan = imagemSegmentada(:,:,1);
end
if tipo_teste == 3
    % SEGMENTA��O POR ALAN - Modificado
    L = 1;
    N = 120;
    R = 6;
    w = 70;
    Th = 1e-2;
    Nb = 4;

    %%
    [phi, psi] = mlsh3_Ric(LE,L,N,R,w,Th,Nb,option);
    imagemSegmentada = double (psi > 0);
    imagemSegmentada_Alan = imagemSegmentada(:,:,1);
end
if tipo_teste == 4
    % SEGMENTA��O POR ALAN - Modificado
    L = 1;
    N = 140;
    R = 6;
    w = 70;
    Th = 1e-2;
    Nb = 8;

    %%
    [phi, psi] = mlsh3_Ric(LE,L,N,R,w,Th,Nb,option);
    imagemSegmentada = double (psi > 0);
    imagemSegmentada_Alan = imagemSegmentada(:,:,1);
end

tAlanFim = toc (tAlanIni);


TempoOstu = tCalculosFim + tOtsuFim;
TempoKmean = tCalculosFim + tKmeanFim;
TempoHuang = tCalculosFim + tHuangFim;
TempoRegis = tCalculosFim + tRegisFim;
TempoAlan = tCalculosFim + tAlanFim;


% Calculando Dist�ncias Estocasticas da imagem segmentada - Threshold
Z_fs = fcn_retvetseg(imagem_gi0, imagemSegmentada_THR);
imagemSegmentada_THR = double(imagemSegmentada_THR ==0);
Z_bs = fcn_retvetseg(imagem_gi0, imagemSegmentada_THR);  
SD_THR_1 = Gi0_arith_distance(Z_fr(:), Z_bs(:), L, L); 
SD_THR_2 = Gi0_arith_distance(Z_fs(:), Z_br(:), L, L); 
CRF_THR = fcn_CRF (DoS, SD_THR_1, SD_THR_2);          

% Calculando Dist�ncias Estocasticas da imagem segmentada - Kmeans
Z_fs = fcn_retvetseg(imagem_gi0, imagemSegmentada_KMS);
imagemSegmentada_KMS = double(imagemSegmentada_KMS ==0);
Z_bs = fcn_retvetseg(imagem_gi0, imagemSegmentada_KMS);
SD_KMS_1 = Gi0_arith_distance(Z_fr(:), Z_bs(:), L, L); 
SD_KMS_2 = Gi0_arith_distance(Z_fs(:), Z_br(:), L, L);             
CRF_KMS = fcn_CRF (DoS, SD_KMS_1, SD_KMS_2);

% Calculando Dist�ncias Estocasticas da imagem segmentada - HUANG
Z_fs = fcn_retvetseg(imagem_gi0, imagemSegmentada_Huang);
imagemSegmentada_Huang = double(imagemSegmentada_Huang ==0);
Z_bs = fcn_retvetseg(imagem_gi0, imagemSegmentada_Huang);
SD_HUANG_1 = Gi0_arith_distance(Z_fr(:), Z_bs(:), L, L); 
SD_HUANG_2 = Gi0_arith_distance(Z_fs(:), Z_br(:), L, L);                         
CRF_HUANG = fcn_CRF (DoS, SD_HUANG_1, SD_HUANG_2);

% Calculando Dist�ncias Estocasticas da imagem segmentada - ZHANG
% Z_fs = fcn_retvetseg(imagem_gi0, imagemSegmentada_Zhang);
% imagemSegmentada_Zhang = double(imagemSegmentada_Zhang ==0);
% Z_bs = fcn_retvetseg(imagem_gi0, imagemSegmentada_Zhang);
% SD_ZHANG_1 = Gi0_arith_distance_MoLC(Z_fr(:), Z_bs(:), L, L); 
% SD_ZHANG_2 = Gi0_arith_distance_MoLC(Z_fs(:), Z_br(:), L, L);                         
% CRF_ZHANG = fcn_CRF (DoS, SD_ZHANG_1, SD_ZHANG_2);

% Calculando Dist�ncias Estocasticas da imagem segmentada - REGIS
Z_fs = fcn_retvetseg(imagem_gi0, imagemSegmentada_Regis);
imagemSegmentada_Regis = double(imagemSegmentada_Regis ==0);
Z_bs = fcn_retvetseg(imagem_gi0, imagemSegmentada_Regis);
SD_Regis_1 = Gi0_arith_distance(Z_fr(:), Z_bs(:), L, L); 
SD_Regis_2 = Gi0_arith_distance(Z_fs(:), Z_br(:), L, L);                         
CRF_Regis = fcn_CRF (DoS, SD_Regis_1, SD_Regis_2);

% Calculando Dist�ncias Estocasticas da imagem segmentada - ALAN
Z_fs = fcn_retvetseg(imagem_gi0, imagemSegmentada_Alan);
imagemSegmentada_Alan = double(imagemSegmentada_Alan ==0);
Z_bs = fcn_retvetseg(imagem_gi0, imagemSegmentada_Alan);
SD_Alan_1 = Gi0_arith_distance(Z_fr(:), Z_bs(:), L, L); 
SD_Alan_2 = Gi0_arith_distance(Z_fs(:), Z_br(:), L, L);                         
CRF_Alan = fcn_CRF (DoS, SD_Alan_1, SD_Alan_2);


figure        
imshow(imagem_gi0, [])
title('Imagem Real');

figure        
imshow(sqrt(imagem_ga0), [])
title('Imagem Real');

figure        
imshow(imagemSegmentada_Huang)
title('Huang');

figure        
imshow(imagemSegmentada_KMS)
title('KMS');

figure        
imshow(imagemSegmentada_THR)
title('THR');

% figure        
% imshow(imagemSegmentada_Zhang)
% title('Zhang');

figure        
imshow(imagemSegmentada_Regis)
title('Regis');

figure        
imshow(imagemSegmentada_Alan)
title('Alan');


% figure        
% imshow(imagemSegmentada_Regis - imagemSegmentada_THR)
% title('Regis - THR');
