function [phi,psi,img,mask,Pt] = mlsh3_Ric(img,L,N,R,w,Th,Nb,option)
%%
%
%
%INPUT:
%img: SAR image in intesity (matrix)
%L: number of looks or ENL (scalar)
%N: maximum number of iterations (scalar)
%R: maximum number of level sets (scalar)
%w: resolution of grid (should be chosen based on ROI size and/or imagem resolution)
%Th: decision threshold factor (usually (Th=10^-k); the decision threshold is Dmax x Th)
%Nb: median filter neighborhood 4 or 8
%
%OUTPUT:
%phi: detected edge
%psi: segmented regions
%Pt: valid nodes of tree
%
%Final results are phi(:,:,Pt) and psi(:,:,Pt)
%

dt=0.5; %time step

[m,n] = size(img);
psi = zeros(m,n);
phi = false(m,n);
mask(:,:,1) = true(m,n);

G=cria_grade(m,n,w);%To make grid matrix
Dmax=0;
i = 0;          %Current node
Pt = ones(1,R); %Auxiliar variable to checked nodes control
Ptn = Pt;       %Auxiliar variable to checked nodes control

Fo=img;

while (i<R)% && sum(Pt(Nd))>0)
                              
    i = i + 1;
    fprintf('Processing node: %d ...\n',i);
        
        if (Pt(i)==1) %If node is not check...do:
            Gt=mask(:,:,i).*G;      
            gi=unique(Gt(Gt>0));
            Lg=length(gi);
            D=zeros(1,Lg);
            for k=1:Lg       %To check distance between grid elements
                
                W1=(Gt==gi(k));
                if sum(W1(:))==(w*w) %To computer distance in mask only
                    W2=((Gt>0) & (Gt~=gi(k)));
                    
                    m1 = mean(img(W1));
                    m2 = mean(img(W2));
                    
                    D(k) = pdist2(m1,m2,'euclidean');    
                    
                    %D(k) = GI_arith_distance(img(W1),img(W2),L,L);
                else
                    D(k)=0;
                end

            end
        
            D=max([0 D]); %To avoid empty matrix
            Dmax=max(Dmax,D);
            fprintf('Max Dist: %f \n',D);
            if (D<(Dmax*Th))||(isnan(Dmax)) %If contrast is low...do:
                Pt(i)=0;             
                Pt(i*2)=0;    %
                Pt(1+i*2)=0;  %
            end

        else
            Pt(i*2)=0;
            Pt(1+i*2)=0;
        end
            
    
    if (Pt(i)==1) %To perform level set over checked node
        
        Ptn(max(1,fix(i/2))) = 0;       %segmented nodes=0
          
% --------- FUN��ES DE LEVEL SET ---------------------------------        

%% MEDIAN LEVEL SET (ALAN)    
    if strcmp(option,'median_leveset') 
        [I_phi, I_psi] = mls2(img,L,mask(:,:,i),dt,Nb,N,Fo);
    end

%%  NARROW BANB LEVEL SET 
%         e=0.025; N=200; 
%         [I_phi,I_psi] =  narrow_band(dt,e,img,L,mask(:,:,i),N); % narrow_band(dt,e,imgo,L,mask,N)
%         [I_phi,img5,I_psi] = mls_2(img,mask(:,:,i),dt,N,L,e);

%%  GAUSSIAN LEVEL SET --> L=looks; Sigma=0.3;0.5;0.75; e= ver tese; dt=0.5; N=200;
    if strcmp(option,'GFLS')
        e = 0.5; N = 200; sigma = 0.75; %0.45 a 1 (menor ru�do (0.45) e maior ru�do(1))
        [I_phi,I_psi] = level_set_demo(img,L,mask(:,:,i),sigma,e,dt,N);   
    end
%%

        phi(:,:,i) = I_phi;             %Storage level set results
        psi(:,:,i) = I_psi < 0;         %Storage level set results
        aux(:,:,1) = (psi(:,:,i)==1) & mask(:,:,i);   %
        aux(:,:,2) = (psi(:,:,i)==0) & mask(:,:,i);   %
        mask(:,:,2*i:1+2*i) = aux;      %Masks of new nodes
        
    end
   
end

for n=2:2:R % To correct tree
    if ((Pt(n)==0 && Pt(n+1)==1 && Ptn(n)==1))
        Pt(n)=1;
        mask(:,:,n)=mask(:,:,n/2);
        phi(:,:,n)=phi(:,:,n/2);
        psi(:,:,n)=psi(:,:,n/2);
    elseif (Pt(n+1)==0 && Pt(n)==1 && Ptn(n+1)==1)
        Pt(n+1)=1;
        mask(:,:,n+1)=~mask(:,:,n/2);
        phi(:,:,n+1)=~phi(:,:,n/2);
        psi(:,:,n+1)=~psi(:,:,n/2);
    end
end

Pt=Pt.*[Ptn ones(1,length(Pt)-length(Ptn))]; %Sort index of 
p = 1:length(Pt);                            %external nodes only
Pt = p(Pt(p)==1);                            %

if sum(Pt)==0 %a single level set 
    Pt=1;
end

%phi0=logical(sum(phi(:,:,Pt),3));                       %final segmented
%imgz = double(gray2ind(mat2gray(log(sqrt(img))),256));  %image
%img(:,:,1)=imgz+255*(phi0); 
%img(:,:,2)=imgz.*(~phi0);
%img(:,:,3)=imgz.*(~phi0);





function [phi,Psi] = mls2(imgo,L,mask,dt,Nb,N,Fo) %MAIN FUNCTION OF FAST LEVEL SET
%%
%FOR A SINGLE LEVEL SET PHASE: MASK=ONES(SIZE(IMGO))
%

figure; % ALAN

imgo = double(imgo);
[x,y] = size(imgo);
% imgz = double((sqrt(imgo)));
Lo =imread('level_zero.bmp'); %Level Set Zero read a file with binary forms
Lo=[Lo Lo;Lo Lo];
Lo = Lo(1:x,1:y);
SEg = strel('disk',1);
F=zeros(x,y);                 

if Nb==4
    Nb=[0 1 0; 1 1 1;0 1 0];
    med=3;
else
    Nb=ones(3);
    med=5;
end

% ----Inicialization of Surface and others 
Psi = -((2*Lo)-1);
Psi_d = imdilate(Psi,SEg);
Psi_e = imerode(Psi,SEg);


% ---- Main procedure
c=1;
phi0 = ones(x,y);
thr = ones(1,N);
warning('off','images:initSize:adjustingMag');
while (c<N)&&((sum(thr==0))<10) % ALAN - coloquei 20. estava s� 10 para HH. %Convergence 
   c=c+1;
   Psi = ordfilt2(Psi + dt*((max(F,0).*Psi_d - min(F,0).*Psi_e)),med,Nb);
   %Psi = (Psi + dt*((max(F,0).*Psi_d - min(F,0).*Psi_e)));
   Psi_d = imdilate(Psi,SEg);
   Psi_e = imerode(Psi,SEg);
   
   phi_1 = bwperim(Psi>0);
   phi_2 = bwperim(Psi<0);
%    phi = phi_1 + phi_2; 
   phi = phi_1; 
   
   thr(c) = sum(sum(abs(phi0-phi))); %threshold of convergence(front stabilization)  
   phi0 = phi;
   
   %%%%%%%%%%Parameter Estimation%%%%%%%%%%%
   Pp = double(Psi>0);%Background
   Pn = double(Psi<0);%Foreground
   
%    A1 = sum(imgo(Pp==1 & mask == 1));
%    A2 = -sum(imgo(Pn==1 & mask == 1));
%    m1 = mean(imgo(Pp==1 & mask == 1));
%    m2 = mean(imgo(Pn==1 & mask == 1));   
%%
   A1 = sum(Psi(Pp==1 & mask == 1));
   A2 = -sum(Psi(Pn==1 & mask == 1));
   m1 = mean(imgo(Pp==1 & mask == 1));
   m2 = mean(imgo(Pn==1 & mask == 1)); 
%%
   
   F = prop_func(A1, A2, m1, m2 ,mask, Fo);
   
   %%%%%%%%%%%%%%%%%%%%To display parcial result%%%%%%%%%%%%%%%%
   if mod(c,2)==0
         pause(0.03);
         imgz = Fo;
         img = imgz;
         img(:,:,1)=imgz+255*(phi); 
         img(:,:,2)=imgz.*(~phi);
         img(:,:,3)=imgz.*(~phi);
%          imshow(uint8(img))
         imshow((img),[])
         title(['itera��es = ', num2str(c)]);
   end
   
end

fprintf('Total of iteractions: %d\n',c);


function grade=cria_grade(X,Y,w)

grade=zeros(X,Y);
k=1;

for x=1:w:X
    for y=1:w:Y
        
        grade(x:min(X,x+w-1),y:min(Y,y+w-1))=k;
        k=k+1;
        
    end
end


function F = prop_func(A1, A2, m1, m2 ,mask, Fo)
%%
F = -(Fo*(1/A1 + 1/A2) - m1/A1 - m2/A2);
F = F.*(F>0)/max(F(:)) + F.*(F<0)/-min(F(:));
F(mask==0) = -1; 
