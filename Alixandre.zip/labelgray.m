function imggray = labelgray(img,scale)
%Fun��o para contamina��o de regioes em imagens sint�ticas com G-Amplitude
%Zero
%
%img = imagem, cada regi�o deve ter um �nico n�vel de cinza
%N = Numero de looks
%G = vetor de gamas
%A = vetor de alfas
[X,Y] = size(img);
imggray = zeros(X,Y);

for i = 1:length(scale)
    imggrayt = (img == i);
    imggrayt = double(imggrayt).*scale(i);
    imggray = imggray + imggrayt;    
end

