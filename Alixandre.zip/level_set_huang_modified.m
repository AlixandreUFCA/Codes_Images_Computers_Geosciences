function [L,D] = level_set_huang_modified(Lo,dt,e,I,Ih,Iw,N,EM,Nclasses, limiar )
% Funcao para calculo do level set
% img = imagem binaria;
% dt = passo de evolu�ao
% EM = Mapa a ser aplicado. Pode ser a matriz de entropia ou a pr�pria
% imagem original
% limiar = caso seja passada a imagem original deve ser informado os
% limiares para que seja aplicado o m�todo original de Huang


%% Initial Level Set function Development
% Perimeter Extraction (inicial form)
L = ~bwperim(Lo); 

% Distance Transform             
D = bwdist(~L);                     
                     
% Signed Distance
D = D.*sinalizacao(L);  

if nargin < 10
  % Threshold da Matriz de Entropia
  limiar = multithresh(EM,Nclasses);
  %limiar = (max(EM(:))+min(EM(:)))/2;
  limiar = limiar(: , 1);
end    

% Velocity Propagation Matrix
Fo = ((Iw).*(EM <= limiar)...       
    + (Ih).*(EM > limiar));       


%% Level Set Aplication

% Stop Criterion Variables' Initialization 
prev = zeros(size(Lo)); curr = ones(size(Lo));
stopNorm = 2;  c=0;

% Level Set Loop
while c<N
    %(norm(curr - prev) > stopNorm)
	 
     c=c+1;
    
    % Take the last current state as the previous one
    prev = curr; 
    
    % Take the current curvature and derivatives upwind  
    [K,Dp,Dn,Grad] = derivadas(D);
    
    % Level Set Equation
    D = D + dt*(...
        -(max(Fo,0).*Dp + min(Fo,0).*Dn)...     %Modelo de Propaga�ao
        +(-e*K).*Grad);                         %Modelo de Curvatura
    
    % New Front computation and visualization
	L = new_level_set(D,I);                    
    
    % Hold the corrent state
    curr = L;   
    
    %disp(norm(curr - prev));
end
%disp(c)


%% Auxiliar Functions
function Dn = new_level_set(D,I)
[A,B] = size(D);
Dn = ones(A,B);

c = fix(contour(D,[0 0]));          %Extra�ao dos pontos onde a fun�ao level set eh 0

for i = 1:length(c)                 %montagem
    if c(1,i)~=0 && c(2,i)~=0        %de uma imagem
%         img(c(2,i),c(1,i)) = 255;
%         img(c(2,i),c(1,i),2) = 0;
%         img(c(2,i),c(1,i),3) = 255;
        Dn(c(2,i),c(1,i)) = 0;      %binaria
    end
end
imshow(Dn),pause(0.00001); % mostra a evolu��o da imagem

function sig = sinalizacao(L)

[imgb] = bwlabel(L,4);                  %Gera rotulos para cada regiao da imagem
sig = ((imgb==1) + -(imgb~=1)).*L;      %O fundo recebe 1 e as demais regioes -1