
function DIST = Gi0_arith_distance(Z1,Z2,L1,L2)
%
%Função computa as distâncias estocasticas propostas em:
%Nascimento,Cintra e Frery, Hypothesis Testing in Speckle Data
%with Stochastic Distances. IEEE Trans. Geoscience and Remote Sensing
%vol 48, N.1 Jan. 2010. pg.373.
%
%Z1 dados ajustados a distribuição 1
%Z2 dados ajustados a distribuição 2
%
[A1,G1] = estima_param_gi0(Z1(:),L1);

[A2,G2] = estima_param_gi0(Z2(:),L2);

DIST = quad(@(x)arith_geometric(x,A1,A2,G1,G2,L1,L2),0,10*mean(Z2));


function f = arith_geometric(x,A1,A2,G1,G2,L1,L2)
    
    f =0.5.*( GI0_pdf(x,A1,G1,L1) + GI0_pdf(x,A2,G2,L2) ).*...
         log(...
                (GI0_pdf(x,A1,G1,L1) + GI0_pdf(x,A2,G2,L2))./...
                (2*...
                    (GI0_pdf(x,A1,G1,L1).*GI0_pdf(x,A2,G2,L2)).^(0.5)... 
                )...
           );
       
       
       
function f=GI0_pdf(z,A,G,L)

f=(L.^L).*gamma(L-A).*(z.^(L-1))./((G.^A).*gamma(-A).*gamma(L).*(G+z.*L).^(L-A));      





function [A G] = estima_param_gi0(img,L)

% amostra: vetor aleatório da distribuição Gi0
% L: Nº de looks
    m1 = mean(img(:));
    m2 = sum(img(:).^0.5)/length(img(:));
    zeta = (m2.^2./m1).*gamma(L).*gamma(L+1)./(gamma(L+0.5)).^2;
    alfa0 = [-97.3:0.0001:-3 -2.99999:0.0001:-1.0001];    
    g = (gamma(-alfa0-0.5).^2)./(gamma(-alfa0).*gamma(-alfa0-1));
    A = interp1(g,alfa0,zeta,'linear');
    if isnan(A)
      A = 0;
      G = 0;
    else
      G = L.*m1.*(gamma(-A).*gamma(L))./(gamma(-A-1).*gamma(L+1));
    end
       
       
       
       
       
       
       