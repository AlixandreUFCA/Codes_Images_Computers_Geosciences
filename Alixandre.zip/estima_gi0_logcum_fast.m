
function[alfas gamas] = estima_gi0_logcum_fast(img,L,J)

matriz_aumentada = [];

% N� de vezes que ser� replicada as linhas / colunas esxternas da imagem
if J==5
    aux = 2;
else
if J==7
    aux = 3; 
else
end
end

% Construindo a nova matriz AUMENTADA

V1 = repmat(img(:,1),1,aux);
matriz_aumentada = [V1 img];

V2 = repmat(matriz_aumentada(1,:),aux,1);
matriz_aumentada = [V2; matriz_aumentada];

V3 = repmat(matriz_aumentada(:,size(matriz_aumentada,2)),1, aux);
matriz_aumentada = [matriz_aumentada V3];

V4 = repmat(matriz_aumentada(size(matriz_aumentada,1),:),aux,1);
matriz_aumentada = [matriz_aumentada;V4];

img_aum = matriz_aumentada;
M = ones(J); % Criando a janela de estima��o

img_aux_1 = log10(img_aum);
img_aux_2 = log10(img_aum.^2);

%Log-momento amostral de ordem 1 = log-cumulante amostral de ordem 1
LM1 = conv2(img_aux_1,M,'same')./(J^2);

LM1(1:aux,:) =[]; % limpa as 'aux' primeiras linhas
LM1(:,1:aux) =[]; % limpa as 'aux' primeiras colunas
LM1(size(LM1,1)-aux+1:end,:) =[]; % limpa as 'aux' �ltimas linhas
LM1(:,size(LM1,2)-aux+1:end) =[]; % limpa as 'aux' �ltimas colunas
 
%Log-momento amostral de ordem 2
LM2 = conv2(img_aux_2,M,'same')./(J^2);

LM2(1:aux,:) =[]; % limpa as 'aux' primeiras linhas
LM2(:,1:aux) =[]; % limpa as 'aux' primeiras colunas
LM2(size(LM2,1)-aux+1:end,:) =[]; % limpa as 'aux' �ltimas linhas
LM2(:,size(LM2,2)-aux+1:end) =[]; % limpa as 'aux' �ltimas colunas
            
%Log-cumulante de ordem 2
K1 = LM1;
k2 = LM2 - LM1.^2;
    

%Calculando as matrizes de par�metros via log-momentos/log-cumulantes
disp('Estimativas encontradas via log-cumulantes em:')
    

    for i=1:size(img,1)
        for j=1:size(img,2)     
            
             
             alfas(i,j) = -sqrt(psi(1,L)- k2(i,j));
             gamas(i,j) = L*exp(K1(i,j)-psi(L)+psi(-alfas(i,j)));
            
                        
        end
    end
    
    
    


            
            
            