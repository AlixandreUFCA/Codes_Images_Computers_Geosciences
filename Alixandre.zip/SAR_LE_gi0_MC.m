%  --- INICIALIZA O PROGRAMA LIMPANDO VARIAVEIS ---
clc;
close all;
clear all;
warning('off');
% -------------------------------------------

% -- PARAMETROS DE GERA��O DA IMAGEM CONTAMINADA --

%zonas extremamente heterogeneas:  ]-3 0[
%zonas heterogeneas             :  ]-6 -3]
%zonas homogeneas               :  ]-inf -6]
alfa1 = [-4 -8 -8 -12 -16]; %[-1.5 -4 -8 -12 -16];
alfa2 = [-1.5 -8 -8 -12 -16]; 
alfa3 = [-4 -8 -8 -12 -16]; 
% [-1.5 -4] -> utilizar otim = 1; 
% [-1.5 -8] -> utilizar otim = 2; 
% [-4 -8] -> utilizar otim = 0    
otim = 0; % 0 - desligado; 1 - ligado para 1look; 2 - ligado para n looks;


% cenario 1 - a : alfas iguais e gamas diferentes fornecidos pelo usu�rio gama = [0.05 0.002 1 10 20]; 
% cenario 2 - b : alfas diferentes e gamas iguais fornecidos pelo usu�rio gama = [0.002 0.002 1 10 20]; 
% cenario 3 - c : alfas diferente e gamas diferentes 

cenario = 3;
gama1 = [0.1 1 1 10 20]; 
%gama1 = [0.09 0.7 1 10 20]; 
gama2 = [1 0.002 0.05 10 20]; 
gama3 = [1 0.05 0.002 10 20]; 


Nlooks = [1 2 3 4 5 6 7 8]; % N�mero de Visadas (Looks) [1 2 3 4 5 6 7 8]
MGo = 1;    % M�dia da Distribui��o Go;
optip = 1;  % imagem em intensidade


L = Nlooks; % N�mero de Visadas (Looks) [1 5 8]
mi = MGo;   % M�dia da Distribui��o Go;

% ----- PARAMETROS PARA M�TODO DE MONTE CARLO -----
maxInt=1;
% -------------------------------------------------

% -------- PARAMETROS PARA M�TODO DO HUANG --------
Sigma = 0.5;
e = 1; 
dt=0.5;
N=100;
% -------------------------------------------------

% ---  PARAMETROS PARA ESTIMA��O E SEGMENTA�AO  ---
windowSize = 5;
TJanela3 = [3 3]; TJanela5 = [5 5]; TJanela7 = [7 7];
% -------------------------------------------------

% ---  PARAMETROS RELACIONADOS AO CONTROLE DE ERROS  ---
TolErro = 0.07;
MaxErro = 20;
Error_THR = zeros(maxInt, 8, 'double');
Error_KMS = zeros(maxInt, 8, 'double');
Error_Huang = zeros(maxInt, 8, 'double');
Error_Regis = zeros(maxInt, 8, 'double');
% -------------------------------------------------

for int_a = 1:3

    if int_a == 1
       alfa = alfa1 
    elseif int_a == 2  
       alfa = alfa2 
    else       
       alfa = alfa3
    end   
                
    for int_b = 1:3
        
        if int_b == 1
           gama = gama1
        elseif int_b == 2  
           gama = gama2 
        else       
           gama = gama3
        end         
        
        
        for contimg = 52:52
            fprintf('***************** Imagem %d ******************** \n', contimg);
            arq = strcat ('Imagens\img', int2str(contimg), '.bmp '); 
            imagemR = imread(arq);
            imagemR=double(imagemR);
            colorseg = [0 1];
            nclasses = 2;
            Lo = double(createLevelSetInitial(size(imagemR)));

            for contLook = 1:size(Nlooks,2)   

%                 if cenario == 3
%                     for i = 1:size(alfa,2)  
%                         gama(i) = L(contLook)*((mi*gamma(-alfa(i))*gamma(L(contLook)))/(gamma(-alfa(i)-1)*gamma(L(contLook)+1)));          
%                     end  
%                 end	
                %% ----------- METODO DE MONTE CARLO ---------------
                nInter = 1;

                fprintf('***************** N�mero de visadas: %d ******************** \n', contLook);

                while (nInter <= maxInt)
                    tic;
                    fprintf('Inicio da Intera��o: %d \n', nInter);

                    disp 'Gerando imagem' ;  
                    imagem_gi0 = contamina_regioes_GI0(imagemR,L(contLook),alfa,gama);


                    disp 'Estimando par�metros' ;

                     if (otim == 1) && (L(contLook) ==1)
                        [As Gs] = estima_gi0_momentos(imagem_gi0, windowSize, L(contLook));
                     elseif (otim == 2)
                             [As Gs] = estima_gi0_momentos(imagem_gi0, windowSize, L(contLook));
                         else
                             [As Gs] = estima_gi0_momentos(imagem_gi0, windowSize, L(contLook));  
                     end        


                    disp 'Calculando Logarithmic expectation - LE' ;
                    [LE]= LogExpectetion(As, Gs, L(contLook));
                    LE_ori = LE;
                    LE = fcnFilterMedian(LE_ori, getnhood(strel('rectangle',TJanela3)));

                    % Calculando Dist�ncias Estocasticas da imagem Real
                    imagemReal = imagemR;
                    Z_fr = fcn_retvetseg(imagem_gi0, imagemReal);
                    imagemReal = double(imagemReal ==0);
                    Z_br = fcn_retvetseg(imagem_gi0, imagemReal);
                    SD_r = Gi0_arith_distance(Z_fr(:),Z_br(:),L(contLook), L(contLook)); 
                    DoS = 1/SD_r;

                    disp 'Segmentando imagem' ;
                    linha = nInter + ((contimg-1)*maxInt);

                    % SEGMENTA��O POR THRESHOLD - LE  
                    thresh = multithresh(LE,nclasses-1); % m�todo de otsu
                    seg_THR = imquantize(LE,thresh, colorseg);
                    imagemSegmentada_THR = double(seg_THR);

                    Error_THR(linha,contLook)  = fcnMetricsSegmentation(imagemR, imagemSegmentada_THR);

                    if Error_THR(linha,contLook) > TolErro 
                       fprintf('THRESHOLD - Erro maior que tolerancia  \n')        
                    end    

                    SNR = fcnSNR(imagemR, imagemSegmentada_THR);
                    [MSE PSNR] = fcnPNSR_MSE(imagemR, imagemSegmentada_THR);
                    [SSI ENL STM SMPI CC ESIh ESIv]  = fcnMetricsSAR(imagemR, imagemSegmentada_THR);
                    [Jaccard,Dice,rfp,rfn]=fcn_sevaluate(imagemR, imagemSegmentada_THR);
                    [mssim, ssim_map] = fcn_ssim(imagemR, imagemSegmentada_THR);            

                    % Calculando Dist�ncias Estocasticas da imagem segmentada - Threshold
                    Z_fs = fcn_retvetseg(imagem_gi0, imagemSegmentada_THR);
                    imagemSegmentada_THR = double(imagemSegmentada_THR ==0);
                    Z_bs = fcn_retvetseg(imagem_gi0, imagemSegmentada_THR);            
                    SD_THR_1 = Gi0_arith_distance(Z_fr(:), Z_bs(:), L(contLook), L(contLook)); 
                    SD_THR_2 = Gi0_arith_distance(Z_fs(:), Z_br(:), L(contLook), L(contLook)); 
                    CRF_THR = fcn_CRF (DoS, SD_THR_1, SD_THR_2);          

                    RES = [SNR MSE PSNR SSI ENL STM SMPI CC(1,2) ESIh ESIv Jaccard Dice rfp rfn mssim Error_THR(linha,contLook) CRF_THR DoS 1 contLook contimg];
                    save resultados.txt RES -append -ascii -tabs;  

                    % SEGMENTA��O POR KMEANS - LE		
                    Error_KMS(linha,contLook)  = 99;
                    ErroSeg = 99;
                    cont = 0;
                    while (Error_KMS(linha,contLook) > TolErro) && (cont < MaxErro)
                        imageKmeans_1  = imgKmeans(LE, nclasses);
                        seg_KMS = labelgray(imageKmeans_1, colorseg);
                        imagemSegmentada = double(seg_KMS);    

                        ErroSeg  = fcnMetricsSegmentation(imagemR, imagemSegmentada);
                        if  Error_KMS(linha,contLook) > ErroSeg 
                            Error_KMS(linha,contLook) = ErroSeg;
                            imagemSegmentada_KMS = imagemSegmentada;
                        end                    

                        if (Error_KMS(linha,contLook) <= TolErro)
                            cont = 99;
                        end    

                        if ErroSeg > TolErro
                           fprintf('KMEANS - Erro maior que tolerancia  \n')      
                        end         
                        cont = cont +1;			
                    end

                    SNR = fcnSNR(imagemR, imagemSegmentada_KMS);
                    [MSE PSNR] = fcnPNSR_MSE(imagemR, imagemSegmentada_KMS);
                    [SSI ENL STM SMPI CC ESIh ESIv]  = fcnMetricsSAR(imagemR, imagemSegmentada_KMS);
                    [Jaccard,Dice,rfp,rfn]=fcn_sevaluate(imagemR, imagemSegmentada_KMS);
                    [mssim, ssim_map] = fcn_ssim(imagemR, imagemSegmentada_KMS);            

                    % Calculando Dist�ncias Estocasticas da imagem segmentada - Kmeans
                    Z_fs = fcn_retvetseg(imagem_gi0, imagemSegmentada_KMS);
                    imagemSegmentada_KMS = double(imagemSegmentada_KMS ==0);
                    Z_bs = fcn_retvetseg(imagem_gi0, imagemSegmentada_KMS);
                    SD_KMS_1 = Gi0_arith_distance(Z_fr(:), Z_bs(:), L(contLook), L(contLook)); 
                    SD_KMS_2 = Gi0_arith_distance(Z_fs(:), Z_br(:), L(contLook), L(contLook));             
                    CRF_KMS = fcn_CRF (DoS, SD_KMS_1, SD_KMS_2);

                    RES = [SNR MSE PSNR SSI ENL STM SMPI CC(1,2) ESIh ESIv Jaccard Dice rfp rfn mssim Error_KMS(linha,contLook) CRF_KMS DoS 2 contLook contimg];
                    save resultados.txt RES -append -ascii -tabs;            


                    %LE = LE_ori;

                    % SEGMENTA��O POR HUANG - LE
                    [LevelSetHuang imagemHuang] = level_set_huang_modified(Lo, dt, e, imagem_gi0, 1, -0.5, N, LE,nclasses-1);
                    SegHuang = imagemHuang > 0;
                    SegHuang = labelgray(SegHuang, colorseg);
                    imagemSegmentada_Huang = double (SegHuang);

                    Error_Huang(linha,contLook)  = fcnMetricsSegmentation(imagemR, imagemSegmentada_Huang);	
                    if Error_Huang(linha,contLook) > TolErro 
                       Seg_Huang = imagemHuang < 0;
                       imagemSegmentada = double (Seg_Huang);        
                       ErroSeg = fcnMetricsSegmentation(imagemR, imagemSegmentada);	

                       if  Error_Huang(linha,contLook) > ErroSeg 
                           Error_Huang(linha,contLook) = ErroSeg;
                           imagemSegmentada_Huang = imagemSegmentada;
                       end                    

                       if Error_Huang(linha,contLook) > TolErro  
                           fprintf('HUANG - Erro maior que tolerancia  \n')   
                       end    
                    end               

                    SNR = fcnSNR(imagemR, imagemSegmentada_Huang);
                    [MSE PSNR] = fcnPNSR_MSE(imagemR, imagemSegmentada_Huang);
                    [SSI ENL STM SMPI CC ESIh ESIv]  = fcnMetricsSAR(imagemR, imagemSegmentada_Huang);
                    [Jaccard,Dice,rfp,rfn]=fcn_sevaluate(imagemR, imagemSegmentada_Huang);
                    [mssim, ssim_map] = fcn_ssim(imagemR, imagemSegmentada_Huang); 

                    % Calculando Dist�ncias Estocasticas da imagem segmentada - Huang
                    Z_fs = fcn_retvetseg(imagem_gi0, imagemSegmentada_Huang);
                    imagemSegmentada_Huang = double(imagemSegmentada_Huang ==0);
                    Z_bs = fcn_retvetseg(imagem_gi0, imagemSegmentada_Huang);
                    SD_HUANG_1 = Gi0_arith_distance(Z_fr(:), Z_bs(:), L(contLook), L(contLook)); 
                    SD_HUANG_2 = Gi0_arith_distance(Z_fs(:), Z_br(:), L(contLook), L(contLook));                         
                    CRF_HUANG = fcn_CRF (DoS, SD_HUANG_1, SD_HUANG_2);

                    RES = [SNR MSE PSNR SSI ENL STM SMPI CC(1,2) ESIh ESIv Jaccard Dice rfp rfn mssim Error_Huang(linha,contLook) CRF_HUANG DoS 3 contLook contimg];             
                    save resultados.txt RES -append -ascii -tabs;            

                    
                    % SEGMENTA��O POR REGIS - PAMI
                    phi = RegisPAMIGa0_Original(LE,LE,0.35,370);
                    imagemSegmentada_Regis = double (phi > 0);   
                    
                    
                    Error_Regis(linha,contLook)  = fcnMetricsSegmentation(imagemR, imagemSegmentada_Regis);	
                    if Error_Regis(linha,contLook) > TolErro 
                       imagemSegmentada = double (phi < 0);
                       ErroSeg = fcnMetricsSegmentation(imagemR, imagemSegmentada);	

                       if  Error_Regis(linha,contLook) > ErroSeg 
                           Error_Regis(linha,contLook) = ErroSeg;
                           imagemSegmentada_Regis = imagemSegmentada;
                       end                    

                       if Error_Regis(linha,contLook) > TolErro 
                           fprintf('REGIS - Erro maior que tolerancia  \n')      
                       end    
                    end 

                    SNR = fcnSNR(imagemR, imagemSegmentada_Regis);
                    [MSE PSNR] = fcnPNSR_MSE(imagemR, imagemSegmentada_Regis);
                    [SSI ENL STM SMPI CC ESIh ESIv]  = fcnMetricsSAR(imagemR, imagemSegmentada_Regis);
                    [Jaccard,Dice,rfp,rfn]=fcn_sevaluate(imagemR, imagemSegmentada_Regis);
                    [mssim, ssim_map] = fcn_ssim(imagemR, imagemSegmentada_Regis);  

                    % Calculando Dist�ncias Estocasticas da imagem segmentada - Regis            
                    Z_fs = fcn_retvetseg(imagem_gi0, imagemSegmentada_Regis);
                    imagemSegmentada_Regis = double(imagemSegmentada_Regis ==0);
                    Z_bs = fcn_retvetseg(imagem_gi0, imagemSegmentada_Regis);
                    SD_REGIS_1 = Gi0_arith_distance(Z_fr(:), Z_bs(:), L(contLook), L(contLook)); 
                    SD_REGIS_2 = Gi0_arith_distance(Z_fs(:), Z_br(:), L(contLook), L(contLook));                         
                    CRF_REGIS = fcn_CRF (DoS, SD_REGIS_1, SD_REGIS_2);

                    RES = [SNR MSE PSNR SSI ENL STM SMPI CC(1,2) ESIh ESIv Jaccard Dice rfp rfn mssim Error_Regis(linha,contLook) CRF_REGIS DoS 4 contLook contimg];             
                    save resultados.txt RES -append -ascii -tabs;           

                    fprintf('Fim da Intera��o: %d \n', nInter);
                    nInter = nInter + 1;
                    toc;
                    fprintf(' \n');
                end;

            end;  
        end;
    end;
end;


