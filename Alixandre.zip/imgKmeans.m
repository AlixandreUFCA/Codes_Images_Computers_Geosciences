function imageSeg  = imgKmeans(inputImage, Ncluster)
    %ab=double(imread('b.png'));
    [nRows,nCols] = size(inputImage);
    

    imageCluster = reshape(inputImage,nRows*nCols,1);

    
    % repeat the clustering 3 times to avoid local minima
    [cluster_idx, cluster_center] = kmeans(imageCluster, Ncluster,'distance','sqEuclidean', ...
                                      'Replicates',2);
 
    imageSeg = reshape(cluster_idx,nRows,nCols);
    
    %imageSeg = (imageSeg-1).*floor(256/(Ncluster-1));
    
end