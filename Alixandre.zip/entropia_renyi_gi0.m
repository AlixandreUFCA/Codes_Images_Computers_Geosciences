function [renyi1] = entropia_renyi_gi0(alfas, gamas, q, windowSize, L)
%function [renyi1 renyi2] = entropia_renyi_gi0(alfas, gamas, q, windowSize, L)

    for i=1:size(alfas,1)
        for j=1:size(alfas,2)     
            
             EntIntegral = quadgk(@(z) (power(power(z,(L-1)).*power((z*L+gamas(i,j)),(alfas(i,j)-L)),q)), 0, inf);
             
             EntIntegral = log(EntIntegral);
             
             renyi1(i,j) = (q*( L*log(L) + log(gamma(L-alfas(i,j))) - alfas(i,j)*log(gamas(i,j)) - log(gamma(-alfas(i,j))) - log(gamma(L))) + ...
                            +EntIntegral)/(1-q) ;             
             if renyi1(i,j) == -Inf || renyi1(i,j) == Inf
                renyi1(i,j) = NaN;
             end    
                        
%              EntIntegral =  quadgk(@(z) (power((power(L,L).*gamma(L-alfas(i,j)).*(power(z,(L-1))).*(power((gamas(i,j) + L.*z),(alfas(i,j) - L))) )./(power(gamas(i,j),(alfas(i,j))).*gamma(-alfas(i,j)).*gamma(L)),q)), 0, inf);
%              renyi2(i,j) = log(EntIntegral)/(1-q);
                        
        end
        
    end    

    renyi1 = padarray(renyi1,[floor(windowSize/2) floor(windowSize/2)],'symmetric','both');
%     renyi2 = padarray(renyi2,[floor(windowSize/2) floor(windowSize/2)],'symmetric','both');
    [nRows,nCols] = size(renyi1);
    
    renyi1_gi0 = renyi1;
%     renyi2_gi0 = renyi2;
    renyi1_NAN = double(isnan(renyi1));
    %renyi2_NAN = double(isnan(renyi2));
    
    tot_NAN = sum(renyi1_NAN(:));
    %tot_NAN = (sum(renyi1_NAN(:)) + sum(renyi2_NAN(:)));
    
    if tot_NAN > 0
        renyi1_Zeros = double(~isnan(renyi1));
    %     renyi2_Zeros = double(~isnan(renyi2));
        for i=ceil(windowSize/2):nRows-floor(windowSize/2)
            for j=ceil(windowSize/2):nCols-floor(windowSize/2)
                if renyi1_Zeros(i,j) == 0           
                   ValRenyi1 = renyi1(i-floor(windowSize/2):i+floor(windowSize/2),j-floor(windowSize/2):j+floor(windowSize/2));
                   renyi1(i,j)= nanmean(ValRenyi1(:));               
                end
    %             if renyi2_Zeros(i,j) == 0           
    %                ValRenyi2 = renyi2(i-floor(windowSize/2):i+floor(windowSize/2),j-floor(windowSize/2):j+floor(windowSize/2));
    %                renyi2(i,j)= nanmean(ValRenyi2(:));               
    %             end
            end
        end
        
        
        renyi1_gi0 = renyi1;
        %renyi2_gi0 = renyi2;

        renyi1_NAN = double(isnan(renyi1));
        %renyi2_NAN = double(isnan(renyi2));

        tot_NAN = sum(renyi1_NAN(:));
        %tot_NAN = (sum(renyi1_NAN(:)) + sum(renyi2_NAN(:)));

        if tot_NAN > 0
            renyi1_Zeros = double(~isnan(renyi1));
        %     renyi2_Zeros = double(~isnan(renyi2));
            for i=nRows-floor(windowSize/2):-1:ceil(windowSize/2)
                for j=nCols-floor(windowSize/2):-1:ceil(windowSize/2)
                    if renyi1_Zeros(i,j) == 0           
                       ValRenyi1 = renyi1(i-floor(windowSize/2):i+floor(windowSize/2),j-floor(windowSize/2):j+floor(windowSize/2));
                       renyi1(i,j)= nanmean(ValRenyi1(:));               
                    end
        %             if renyi2_Zeros(i,j) == 0           
        %                ValRenyi2 = renyi2(i-floor(windowSize/2):i+floor(windowSize/2),j-floor(windowSize/2):j+floor(windowSize/2));
        %                renyi2(i,j)= nanmean(ValRenyi2(:));               
        %             end
                end
            end    
        end
        
        
        
    end

    

    
    renyi1 = renyi1(ceil(windowSize/2):nRows-floor(windowSize/2),ceil(windowSize/2):nCols-floor(windowSize/2));
%     renyi2 = renyi2(ceil(windowSize/2):nRows-floor(windowSize/2),ceil(windowSize/2):nCols-floor(windowSize/2));           
    
    
    
    
    