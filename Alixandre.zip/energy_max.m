function [zmax,grad] = energy_max(z,imgz,A,G,alfa_true,n,op)
% 
%Fun��o para calculo do delta que maximiza o funcional de energia
%A fun��o utiliza os m�todos op=1: Newton-Raphson; op=2: quasi-Newton (BFGS); 
%op=3: true region Newton 
%para encontrar o delta que maximiza -|\nabla E| = f_ga0 * |\nabla Z|
%
%sintax:[zmax,grad] = energy_max(z,imgz,A,G,n)
%
%zmax = delta que maximiza a fun��o
%grad = gradiente no ponto zmax
%
%z = ponto inicial 
%imgz = imagem SAR
%A = mapa dos valores de alfa estimados
%G = mapa dos valores de gama estimados
%n = n�mero de looks

A = A(:);
G = G(:);
[Gx,Gy]=gradient(imgz);
Gb = (Gx.^2 + Gy.^2);
Gb = Gb(:);

M = 2*n^n*gamma(n-A)./((G.^A).*gamma(-A).*gamma(n));
p = ~isnan(M) & ~isinf(M);% & alfa_true(:);
length(p)
g = G(p);
a = A(p);
Grad = Gb(p);

if op==1
    [zmax,grad] = newton(Grad,a,g,n,z);
elseif op==2
    op=optimset('MaxFunEvals',1000,'Display','final','LargeScale','off','GradObj','off','HessUpdate','bfgs','TolFun',1e-7);
    [zmax,feval,exitflag,output,grad]= fminunc('energy_variation',z,op,Grad,a,g,n);
elseif op==3
    op=optimset('MaxFunEvals',1000,'Display','final','LargeScale','on','GradObj','on','HessUpdate','bfgs','TolFun',1e-7);
    [zmax,feval,exitflag,output,grad]= fminunc('energy_variation',z,op,Grad,a,g,n);
end