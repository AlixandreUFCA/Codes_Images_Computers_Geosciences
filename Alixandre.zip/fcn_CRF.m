function CRF = fcn_CRF(DoS, SD_1, SD_2)
% DoS  - Dificuldade de Segmenta��o 
% SD_1 - Distancia estocastica de Zfr - Zbs
% SD_1 - Distancia estocastica de Zfs - Zbr
    
    x = sqrt(DoS*abs(SD_1-SD_2));
     
    CRF =  1/(1+x);
    