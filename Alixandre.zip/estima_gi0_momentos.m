
function [As Gs] = estima_gi0_momentos(inputImage, windowSize, L)

inputImage = padarray(inputImage,[floor(windowSize/2) floor(windowSize/2)],'symmetric','both');
[nRows,nCols] = size(inputImage);

  J = windowSize;

    M = ones(J); % Criando a janela de estima��o

    img_aux_1 = inputImage;
    img_aux_2 = inputImage.^0.5;

    
    %Momento amostral de ordem 1 
    M1 = conv2(img_aux_1,M,'same')./(J^2);

    %Momento amostral de ordem 2
    M2 = conv2(img_aux_2,M,'same')./(J^2);
    
    % faz a estimativa atrav�s da interpola��o
    zeta = (M2.^2./M1).*gamma(L).*gamma(L+1)./((gamma(L+0.5)).^2);
    alfa0 = [-97.3:0.0001:-3 -2.99999:0.0001:-1.0001];
    g = (gamma(-alfa0-0.5).^2)./(gamma(-alfa0).*gamma(-alfa0-1));   
    As = interp1(g,alfa0,zeta,'linear');
    if isnan(As)
        As=0;
        Gs=0;
    else
        Gs = L.*M1.*(gamma(-As).*gamma(L))./(gamma(-As-1).*gamma(L+1));
    end
    
    for i=1:nRows
        for j=1:nCols
            if isnan(As(i,j))           
               As(i,j) = 0;
               Gs(i,j) = 0;  
            end
        end
    end
    
    

AlfasZeros = double(As~=0);
GamasZeros = double(Gs~=0);
for i=ceil(windowSize/2):nRows-floor(windowSize/2)
    for j=ceil(windowSize/2):nCols-floor(windowSize/2)
        if AlfasZeros(i,j) == 0           
           ValAlfas = As(i-floor(windowSize/2):i+floor(windowSize/2),j-floor(windowSize/2):j+floor(windowSize/2));
           IndAlfas = AlfasZeros(i-floor(windowSize/2):i+floor(windowSize/2),j-floor(windowSize/2):j+floor(windowSize/2));    
           Jan = sum(sum(IndAlfas(:)));
           valor = sum(sum(ValAlfas.*IndAlfas))/Jan;  
           %if ~isnan(valor)  
              As(i,j)= valor;  
              AlfasZeros(i,j) = 1;
           %end   
        end
        if GamasZeros(i,j) == 0           
           ValGamas = Gs(i-floor(windowSize/2):i+floor(windowSize/2),j-floor(windowSize/2):j+floor(windowSize/2));
           IndGamas = GamasZeros(i-floor(windowSize/2):i+floor(windowSize/2),j-floor(windowSize/2):j+floor(windowSize/2));    
           Jan = sum(sum(IndGamas(:)));
           valor = sum(sum(ValGamas.*IndGamas))/Jan; 
           %if ~isnan(valor)
              Gs(i,j)= valor;  
              GamasZeros(i,j) = 1;
           %end   
        end
    end
end

As = As(ceil(windowSize/2):nRows-floor(windowSize/2),ceil(windowSize/2):nCols-floor(windowSize/2));
Gs = Gs(ceil(windowSize/2):nRows-floor(windowSize/2),ceil(windowSize/2):nCols-floor(windowSize/2));
