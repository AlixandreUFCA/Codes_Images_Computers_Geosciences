
function [LE] = LogExpectetion(As, Gs,  L)

    LE = log(Gs) - psi(-As) +psi(L) -log(L);
    %LE = log(Gs) - psi(-As) +psi(L) +log(L);
    