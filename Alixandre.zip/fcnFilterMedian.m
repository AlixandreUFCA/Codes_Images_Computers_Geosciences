function outputImage = fcnFilterMedian(inputImage, mask)

% fcnFilterMedian performs noise filtering on an image based
%   inputImage: Imagem SAR
%   mask: Use getnhood(strel('rectangle',[3 3]))

% Example
% -------
% inputImage = imnoise(imread('cameraman.tif'),'speckle',0.01);
% outputImage1 = fcnFilterMedian(inputImage);
% outputImage2 = ...
% fcnFilterMean(inputImage,getnhood(strel('rectangle',[3 3])));
% figure, subplot 131, imshow(inputImage), subplot 132,
% imshow(outputImage1), subplot 133, imshow(outputImage2)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Input argument check
iptcheckinput(inputImage,{'uint8','uint16','uint32','uint64','int8','int16','int32','int64','single','double'}, {'nonsparse','2d'}, mfilename,'I',1);

if nargin == 1
    mask = getnhood(strel('rectangle',[3 3]));
elseif nargin == 2
    if ~islogical(mask)
        error('Mask of neighborhood specified must be a logical valued matrix');
    end
end

imageType = class(inputImage);

windowSize = size(mask);

inputImage = padarray(inputImage,[floor(windowSize(1)/2) floor(windowSize(2)/2)],'symmetric','both');

inputImage = double(inputImage);

[nRows,nCols] = size(inputImage);

outputImage = double(inputImage);

for i=ceil(windowSize(1)/2):nRows-floor(windowSize(1)/2)
    for j=ceil(windowSize(2)/2):nCols-floor(windowSize(2)/2)        
        localNeighborhood = inputImage(i-floor(windowSize(1)/2):i+floor(windowSize(1)/2),j-floor(windowSize(2)/2):j+floor(windowSize(2)/2));
        localNeighborhood = localNeighborhood(mask);
        localMedian = median(localNeighborhood(:));
        outputImage(i,j) = localMedian;
    end
end

outputImage = outputImage(ceil(windowSize(1)/2):nRows-floor(windowSize(1)/2),ceil(windowSize(2)/2):nCols-floor(windowSize(2)/2));

outputImage = cast(outputImage,imageType);