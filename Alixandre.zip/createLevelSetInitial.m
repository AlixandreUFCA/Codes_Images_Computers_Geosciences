function [Lo] = createLevelSetInitial( sizeImg )

% Useful for tests
if nargin == 0
    sizeImg = [100 100];
end

%% Initial Level Set Matrix Creation
% Initialization (white background)
Lo = ones(sizeImg);

% Square size 
sideSize = 1;  

% Shift from the right lateral and top of the entire matrix  
lateralShift = 5; 

% Spacing between squares
spacing = 20; 

% PLacing the squares sideSize X sideSize
for i = lateralShift: sideSize + spacing : sizeImg(1)
    for j = lateralShift : sideSize + spacing : sizeImg(2)
        Lo(i+1:i+sideSize,j+1:j+sideSize) = zeros(sideSize);
    end
end

% Tranforming on a gray level matrix e removing the resilients lines or 
% columns
Lo = 255*Lo(1:sizeImg(1),1:sizeImg(2));

%imshow(Lo);

end

