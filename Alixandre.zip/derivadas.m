function [K,Dp,Dn,Grad] = derivadas(D)

fi = bordas2d(D,1,'mirror');
[A,B] = size(fi);

%Derivadas a esquerda
Dxn = fi(2:A-1,2:B-1) - fi(1:A-2,2:B-1);
Dyn = fi(2:A-1,2:B-1) - fi(2:A-1,1:B-2);

%Derivadas a direita
Dxp = fi(3:A,2:B-1) - fi(2:A-1,2:B-1);
Dyp = fi(2:A-1,3:B) - fi(2:A-1,2:B-1);

%Derivadas centrais
[Dx,Dy] = gradient(D);
[Dxx,Dxy] = gradient(Dx);
[Dyx,Dyy] = gradient(Dy);
Grad = (Dx.^2 + Dy.^2).^0.5;

%Delta(+ e -)
Dp = (max(Dxn,0).^2 + min(Dxp,0).^2 + max(Dyn,0).^2 + min(Dyp,0).^2).^0.5;
Dn = (max(Dxp,0).^2 + min(Dxn,0).^2 + max(Dyp,0).^2 + min(Dyn,0).^2).^0.5;

%Curvatura
K1 = (Dx.^2 + Dy.^2).^1.5;
% K1 = (K1==0).*0.00001 + (K1~=0).*K1;
K1 = (abs(K1)<=0.01).*1e10 + (abs(K1)>0.01).*K1;
K = -(Dxx.*(Dy.^2) - 2.*Dx.*Dy.*Dxy + Dyy.*(Dx.^2))./K1;
K(1,:) = 0; K(end,:) = 0; K(:,1) = 0; K(:,end) = 0;