function vetseg = fcn_retvetseg(imagereal, subimageseg)

    imgSeg =  subimageseg.* imagereal;
    
    [nRows,nCols] = size(imgSeg);
    

    cont = 1;
    for i=1:nRows
      
        for j=1:nCols            
            
             if imgSeg(i,j) ~= 0
                 vetseg(1,cont) = imgSeg(i,j);
                 cont = cont + 1;
             end       
        end
    end